package com.ai.jwd48.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ai.jwd48.model.User;
import com.ai.jwd48.repositories.UserRepo;

@Service
public class UserService {
	@Autowired
	private UserRepo repo;

	public boolean checkUserNameAndPassword(String username, String password) {

		User user = repo.findByUserName(username);

		if (null == user) {
			return false;
		} else {
			if (password.equals(user.getPassword())) {
				return true;
			} else {
				return false;
			}
		}
	}

	public void userCreate(User user) {
		repo.userCreate(user);
	}

	public List<User> findAllUser() {

		List<User> users = repo.findAllUser();
		return users;
	}

	public User findStudentById(int id) {

		return repo.findUserById(id);
	}
	public void updateUser(User user) {
		repo.update(user);
	}
}
