package com.ai.jwd48.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ai.jwd48.model.User;
import com.ai.jwd48.services.UserService;

@Controller
public class LoginController {
	@Autowired
	private UserService userService;

	@GetMapping({ "/", "/login" })
	public String login() {
		return "login";
	}

	@PostMapping("/login")
	public String login(User User, ModelMap model, HttpSession session) {

		if (userService.checkUserNameAndPassword(User.getUsername(), User.getPassword())) {
			session.setAttribute("loginUserName", User.getUsername());
			return "topMenu";
		} else {
			model.addAttribute("message", "Invalid User Name and Password!!!");
			return "login";
		}
	}

}
