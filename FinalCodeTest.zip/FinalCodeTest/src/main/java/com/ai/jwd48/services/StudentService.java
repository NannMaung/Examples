package com.ai.jwd48.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ai.jwd48.model.Student;
import com.ai.jwd48.repositories.StudentRepo;

@Service
public class StudentService {
	@Autowired
	private StudentRepo repo;

	public void saveStudent(Student student) {

		repo.saveStudent(student);
	}
}
