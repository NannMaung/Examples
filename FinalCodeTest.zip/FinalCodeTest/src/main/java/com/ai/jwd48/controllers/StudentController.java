package com.ai.jwd48.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ai.jwd48.model.Student;
import com.ai.jwd48.services.StudentService;

@Controller
public class StudentController {
	@Autowired
	public StudentService studentService;

	@GetMapping("/studentRegister")
	public String studentRegister() {
		return "studentRegister";
	}

	@PostMapping("/studentRegisterPost")
	public String studentRegisterPost(Student Student, HttpSession session) {
		Student student = new Student();
		student.setName(Student.getName());
		student.setDob(Student.getDob());
		student.setPhoneNumber(Student.getPhoneNumber());
		student.setEducation(Student.getEducation());
		student.setAttend(Student.getAttend());
		student.setGender(Student.getGender());
		student.setPhoto(Student.getPhoto());
		studentService.saveStudent(student);
		return "redirect:/topMenu";
	}
}
