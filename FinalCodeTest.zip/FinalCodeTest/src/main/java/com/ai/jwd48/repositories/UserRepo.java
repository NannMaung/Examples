package com.ai.jwd48.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ai.jwd48.model.User;

@Component
public class UserRepo extends DBContext {
	public User findByUserName(String username) {
		User user = null;
		try {
			Connection conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("Select * from user where username = ? ");
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		return user;
	}

	public void userCreate(User user) {
		Connection conn = getConnection();
		try {
			PreparedStatement ps = conn
					.prepareStatement("INSERT INTO user (username,password,role,email)" + "VALUES(?,?,?,?);");
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ps.setString(4, user.getEmail());
			ps.execute();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	public List<User> findAllUser() {
		List<User> users = new ArrayList<>();
		Connection conn = getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from user ");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setEmail(rs.getString("email"));
				user.setRole(rs.getString("role"));
				users.add(user);
			}
		} catch (SQLException e) {

		}
		return users;
	}

	public User findUserById(int id) {
		User user = null;
		Connection conn = getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("select * from user where Id = ?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setUsername(rs.getString("username"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setRole(rs.getString("role"));
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return user;
	}

	public void update(User user) {
		Connection conn = getConnection();
		try {
			PreparedStatement ps = conn
					.prepareStatement("Update user set username=?,password=?,role=?,email=? where id=?");
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getRole());
			ps.setString(4, user.getEmail());
			ps.setInt(5, user.getId());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}
