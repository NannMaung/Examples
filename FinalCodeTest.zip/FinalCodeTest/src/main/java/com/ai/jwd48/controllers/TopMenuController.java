package com.ai.jwd48.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class TopMenuController {
	@GetMapping("/topMenu")
	public String welcome() {
		return "topMenu";
	}

}
