package com.ai.jwd48.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Component;

import com.ai.jwd48.model.Student;

@Component
public class StudentRepo extends DBContext {
	public void saveStudent(Student student) {

		Connection conn = getConnection();

		try {
			PreparedStatement ps = conn.prepareStatement(
					"Insert Into Student_info (Name ,date_of_birth, gender, phone_number,education,attend,photo)"
							+ "VALUES (?,?,?,?,?,?,?);");

			ps.setString(1, student.getName());
			ps.setString(2, student.getDob());
			ps.setString(3, student.getGender());
			ps.setString(4, student.getPhoneNumber());
			ps.setString(5, student.getEducation());
			ps.setString(6, student.getAttend());
			ps.setString(7, student.getPhoto());
			ps.execute();

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

	}

	public static int AIid() {
		int autoIncreamentalId = 0;
		Connection conn = getConnection();
		try {
			PreparedStatement ps = conn.prepareStatement("SELECT MAX(id) as studentId FROM student_info");
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {

				autoIncreamentalId = rs.getInt("studentId");

			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return autoIncreamentalId;
	}

}
