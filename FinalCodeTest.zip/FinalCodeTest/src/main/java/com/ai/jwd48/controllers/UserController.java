package com.ai.jwd48.controllers;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ai.jwd48.dto.UserDTO;
import com.ai.jwd48.model.User;
import com.ai.jwd48.services.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@GetMapping("/user")
	public String user() {
		return "userCreate";
	}

	@GetMapping("/userCreate")
	public String userCreate(UserDTO UserDTO, ModelMap model, HttpSession session) {
		if (UserDTO.getUsername() != "" && UserDTO.getRole() != "" && UserDTO.getPassword() != ""
				&& UserDTO.getConPassword() != "") {
			if (UserDTO.getPassword().equals(UserDTO.getConPassword())) {
				User user = new User();
				user.setUsername(UserDTO.getUsername());
				user.setPassword(UserDTO.getPassword());
				user.setRole(UserDTO.getRole());
				user.setEmail(UserDTO.getEmail());

				userService.userCreate(user);
				session.setAttribute("regMessage", "Create User Successfully!");
				session.setAttribute("loginUsername", UserDTO.getUsername());
				return "redirect:/topMenu";

			} else {
				session.setAttribute("regMessage", "Create User Failed!");

				return "login";

			}
		} else {
			session.setAttribute("regMessage", "Create User Failed!");

			return "login";
		}

	}

	@GetMapping("/userList")
	public String userList(User User, ModelMap model) {
		List<User> users = userService.findAllUser();
		model.addAttribute("users", users);
		return "user";
	}

	@GetMapping("/update")
	public String updateUser(User User, ModelMap model) {
		int id = Integer.valueOf(User.getId());
		User user = userService.findStudentById(id);
		model.addAttribute("user", user);
		return "update";
	}

	@PostMapping("/update")
	public String updatedUser(User User, ModelMap model) {
		User user = new User();
		user.setId(Integer.valueOf(User.getId()));
		user.setUsername(User.getUsername());
		user.setPassword(User.getPassword());
		user.setEmail(User.getEmail());
		user.setRole(User.getRole());
		userService.updateUser(user);
		return "redirect:/user";
	}
}
